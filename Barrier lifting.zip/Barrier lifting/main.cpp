#include <stdio.h>
#include <stdlib.h>
#include "face_recognition.h"
#include "plate_recognition.h"
#include "pwm.h"
#include "oled.h"

#define SERVO_PIN        5   // 假设舵机连接在GPIO5上
#define SERVO_FREQ       50  // 舵机PWM频率为50Hz
#define SERVO_MIN_PULSE  500 // 舵机最小脉冲宽度为500us
#define SERVO_MAX_PULSE  2500// 舵机最大脉冲宽度为2500us
#define SERVO_NEUTRAL    1500// 舵机中位脉冲宽度为1500us

bool FaceRecognized = false;
bool PlateRecognized = false;

void ServoWrite(int angle) {
    int pulse_width;
    pulse_width = SERVO_MIN_PULSE + (angle * (SERVO_MAX_PULSE - SERVO_MIN_PULSE) / 180);
    PwmSetPulseWidth(SERVO_PIN, pulse_width);
}

void DisplayResult(bool faceOk, bool plateOk) {
    OledClear();
    OledSetCursor(0, 0);
    if (faceOk && plateOk) {
        OledPrint("Face & Plate OK");
        ServoWrite(90); // 舵机回到中位
    } else if (faceOk) {
        OledPrint("Face OK");
        ServoWrite(0); // 舵机转到0度
    } else if (plateOk) {
        OledPrint("Plate OK");
        ServoWrite(180); // 舵机转到180度
    } else {
        OledPrint("No Match");
        ServoWrite(90); // 舵机回到中位
    }
    OledRefresh();
}

int main() {
    // 初始化PWM和OLED
    PwmInit(SERVO_PIN, SERVO_FREQ);
    OledInit();

    // 进入识别循环
    while (1) {
        // 人脸识别
        FaceRecognized = FaceRecognitionTask();

        // 车牌识别
        PlateRecognized = PlateRecognitionTask(recognizedPlate, sizeof(recognizedPlate));

        // 如果人脸识别和车牌识别都正确,调用舵机函数
        if (FaceRecognized && PlateRecognized) {
            ServoWrite(90); // 舵机回到中位
        }

        // 显示识别结果
        DisplayResult(FaceRecognized, PlateRecognized, recognizedPlate);

        // 暂停一段时间后再继续循环
        OsTaskSleep(1000); // 1秒钟
    }

    // 释放资源
    PwmDeInit(SERVO_PIN);
    OledDeInit();

    return 0;
}