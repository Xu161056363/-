
import cv2
import os
import sys
import xlwt
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

# 引入识别接口
from Recognition import Recognition


# 界面设计类
class Ui_MainWindow(QMainWindow):
    # 初始化参数
    def __init__(self):
        super().__init__()
        self.RowLength = 0  # 行数
        # 存放数据的全局变量列表
        self.Data = [['文件名称', '录入时间', '车牌号码', '车牌类型', '车牌信息']]

    # 设置界面
    def setupUi(self, MainWindow):
        # 窗口设计
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1213, 670)
        MainWindow.setFixedSize(1213, 670)  # 设置窗体固定大小
        MainWindow.setToolButtonStyle(QtCore.Qt.ToolButtonIconOnly)

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.scrollArea = QtWidgets.QScrollArea(self.centralwidget)
        self.scrollArea.setGeometry(QtCore.QRect(690, 40, 511, 460))
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QtWidgets.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 500, 489))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.label_0 = QtWidgets.QLabel(self.scrollAreaWidgetContents)
        self.label_0.setGeometry(QtCore.QRect(10, 10, 111, 20))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_0.setFont(font)
        self.label_0.setObjectName("label_0")
        self.label = QtWidgets.QLabel(self.scrollAreaWidgetContents)
        self.label.setGeometry(QtCore.QRect(10, 40, 481, 420))
        self.label.setObjectName("label")
        self.label.setAlignment(Qt.AlignCenter)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.scrollArea_2 = QtWidgets.QScrollArea(self.centralwidget)
        self.scrollArea_2.setGeometry(QtCore.QRect(10, 10, 671, 631))
        self.scrollArea_2.setWidgetResizable(True)
        self.scrollArea_2.setObjectName("scrollArea_2")
        self.scrollAreaWidgetContents_1 = QtWidgets.QWidget()
        self.scrollAreaWidgetContents_1.setGeometry(QtCore.QRect(0, 0, 669, 629))
        self.scrollAreaWidgetContents_1.setObjectName("scrollAreaWidgetContents_1")
        self.label_1 = QtWidgets.QLabel(self.scrollAreaWidgetContents_1)
        self.label_1.setGeometry(QtCore.QRect(10, 10, 111, 20))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_1.setFont(font)
        self.label_1.setObjectName("label_1")
        self.tableWidget = QtWidgets.QTableWidget(self.scrollAreaWidgetContents_1)
        self.tableWidget.setGeometry(QtCore.QRect(10, 40, 651, 581))  # 581))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setColumnWidth(0, 140)  # 设置1列的宽度
        self.tableWidget.setColumnWidth(1, 130)  # 设置2列的宽度
        self.tableWidget.setColumnWidth(2, 110)  # 设置3列的宽度
        self.tableWidget.setColumnWidth(3, 90)  # 设置4列的宽度
        self.tableWidget.setColumnWidth(4, 181)  # 设置5列的宽度
        self.tableWidget.setHorizontalHeaderLabels(["图片名称", "识别时间", "车牌号码", "车牌类型", "车牌信息"])
        self.tableWidget.setRowCount(self.RowLength)
        self.tableWidget.verticalHeader().setVisible(False)  # 隐藏垂直表头)
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableWidget.raise_()

        self.scrollArea_2.setWidget(self.scrollAreaWidgetContents_1)
        self.scrollArea_3 = QtWidgets.QScrollArea(self.centralwidget)
        self.scrollArea_3.setGeometry(QtCore.QRect(690, 510, 341, 131))
        self.scrollArea_3.setWidgetResizable(True)
        self.scrollArea_3.setObjectName("scrollArea_3")
        self.scrollAreaWidgetContents_3 = QtWidgets.QWidget()
        self.scrollAreaWidgetContents_3.setGeometry(QtCore.QRect(0, 0, 339, 129))
        self.scrollAreaWidgetContents_3.setObjectName("scrollAreaWidgetContents_3")
        self.label_2 = QtWidgets.QLabel(self.scrollAreaWidgetContents_3)
        self.label_2.setGeometry(QtCore.QRect(10, 10, 111, 20))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.scrollAreaWidgetContents_3)
        self.label_3.setGeometry(QtCore.QRect(10, 40, 321, 81))
        self.label_3.setObjectName("label_3")
        self.scrollArea_3.setWidget(self.scrollAreaWidgetContents_3)
        self.scrollArea_4 = QtWidgets.QScrollArea(self.centralwidget)
        self.scrollArea_4.setGeometry(QtCore.QRect(1040, 510, 161, 131))
        self.scrollArea_4.setWidgetResizable(True)
        self.scrollArea_4.setObjectName("scrollArea_4")
        self.scrollAreaWidgetContents_4 = QtWidgets.QWidget()
        self.scrollAreaWidgetContents_4.setGeometry(QtCore.QRect(0, 0, 159, 129))
        self.scrollAreaWidgetContents_4.setObjectName("scrollAreaWidgetContents_4")
        self.pushButton_2 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pushButton_2.setGeometry(QtCore.QRect(20, 50, 121, 31))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pushButton.setGeometry(QtCore.QRect(20, 90, 121, 31))
        self.pushButton.setObjectName("pushButton")
        self.label_4 = QtWidgets.QLabel(self.scrollAreaWidgetContents_4)
        self.label_4.setGeometry(QtCore.QRect(10, 10, 111, 20))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.scrollArea_4.setWidget(self.scrollAreaWidgetContents_4)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.pushButton.clicked.connect(self.open_image)  # 设置点击事件
        self.pushButton.setStyleSheet(
            '''QPushButton{background:#222225;border-radius:5px;}QPushButton:hover{background:#2B2B2B;}''')
        self.pushButton_2.clicked.connect(self.write_Files)  # 设置点击事件
        self.pushButton_2.setStyleSheet(
            '''QPushButton{background:#222225;border-radius:5px;}QPushButton:hover{background:#2B2B2B;}''')
        self.retranslateUi(MainWindow)

        self.close_widget = QtWidgets.QWidget(self.centralwidget)
        self.close_widget.setGeometry(QtCore.QRect(1130, 0, 90, 50))
        self.close_widget.setObjectName("close_widget")
        self.close_layout = QGridLayout()  # 创建左侧部件的网格布局层
        self.close_widget.setLayout(self.close_layout)  # 设置左侧部件布局为网格

        self.left_close = QPushButton("x")  # 关闭按钮
        self.left_close.clicked.connect(self.close)
        self.left_mini = QPushButton("-")  # 最小化按钮
        self.left_mini.clicked.connect(MainWindow.mini)
        self.close_layout.addWidget(self.left_mini, 0, 1, 1, 1)
        self.close_layout.addWidget(self.left_close, 0, 2, 1, 1)
        self.left_close.setFixedSize(15, 15)  # 设置关闭按钮的大小
        self.left_mini.setFixedSize(15, 15)  # 设置最小化按钮大小


        self.left_close.setStyleSheet(
            '''QPushButton{background:#F76677;border-radius:5px;}QPushButton:hover{background:red;}''')
        self.left_mini.setStyleSheet(
            '''QPushButton{background:#6DDF6D;border-radius:5px;}QPushButton:hover{background:green;}''')

        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.ProjectPath = os.getcwd()  # 获取当前工程文件位置

        self.centralwidget.setStyleSheet('''
             QWidget#centralwidget{
             color:white;
             background:#222225;
             border-top:1px solid #222225;
             border-bottom:1px solid #222225;
             border-right:1px solid #222225;
             border-left:1px solid #444444;
             border-top-left-radius:10px;
             border-top-right-radius:10px;
             border-bottom-left-radius:10px;
             border-bottom-right-radius:10px;
             }
             ''')
        sc = '''
             QWidget{
             color:white;
             background:#2B2B2B;
             border-top:1px solid #222225;
             border-bottom:1px solid #222225;
             border-right:1px solid #222225;
             border-left:1px solid #444444;
             border-top-left-radius:10px;
             border-top-right-radius:10px;
             border-bottom-left-radius:10px;
             border-bottom-right-radius:10px;
             }

             '''

        self.scrollAreaWidgetContents_1.setStyleSheet('''
             QWidget{
             color:black;
             background:#2B2B2B;
             border-top:1px solid #222225;
             border-bottom:1px solid #222225;
             border-right:1px solid #222225;
             border-left:1px solid #444444;
             border-top-left-radius:10px;
             border-top-right-radius:10px;
             border-bottom-left-radius:10px;
             border-bottom-right-radius:10px;
             }
                      QListWidget{background-color:#2B2B2B;color:#222225}
         /*垂直滚动条*/
         QScrollBar:vertical{
             width:12px;
             border:1px solid #2B2B2B;
             margin:0px,0px,0px,0px;
             padding-top:0px;
             padding-bottom:0px;
         }
         QScrollBar::handle:vertical{
             width:3px;
             background:#4B4B4B;
             min-height:3;
         }
         QScrollBar::handle:vertical:hover{
             background:#3F3F3F;
             border:0px #3F3F3F;
         }
         QScrollBar::sub-line:vertical{
             width:0px;
             border-image:url(:/Res/scroll_left.png);
             subcontrol-position:left;
         }
         QScrollBar::sub-line:vertical:hover{
             height:0px;
             background:#222225;
             subcontrol-position:top;
         }
         QScrollBar::add-line:vertical{
             height:0px;
             border-image:url(:/Res/scroll_down.png);
             subcontrol-position:bottom;
         }
         QScrollBar::add-line:vertical:hover{
             height:0px;
             background:#3F3F3F;
             subcontrol-position:bottom;
         }
         QScrollBar::add-page:vertical{
             background:#2B2B2B;
         }
         QScrollBar::sub-page:vertical{
             background:#2B2B2B;
         }
         QScrollBar::up-arrow:vertical{
             border-style:outset;
             border-width:0px;
         }
         QScrollBar::down-arrow:vertical{
             border-style:outset;
             border-width:0px;
         }

         QScrollBar:horizontal{
             height:12px;
             border:1px #2B2B2B;
             margin:0px,0px,0px,0px;
             padding-left:0px;
             padding-right:0px;
         }
         QScrollBar::handle:horizontal{
             height:16px;
             background:#4B4B4B;
             min-width:20;
         }
         QScrollBar::handle:horizontal:hover{
             background:#3F3F3F;
             border:0px #3F3F3F;
         }
         QScrollBar::sub-line:horizontal{
             width:0px;
             border-image:url(:/Res/scroll_left.png);
             subcontrol-position:left;
         }
         QScrollBar::sub-line:horizontal:hover{
             width:0px;
             background:#2B2B2B;
             subcontrol-position:left;
         }
         QScrollBar::add-line:horizontal{
             width:0px;
             border-image:url(:/Res/scroll_right.png);
             subcontrol-position:right;
         }
         QScrollBar::add-line:horizontal:hover{
             width:0px;
             background::#2B2B2B;
             subcontrol-position:right;
         }
         QScrollBar::add-page:horizontal{
                    background:#2B2B2B;
         }
         QScrollBar::sub-page:horizontal{
                     background:#2B2B2B;
         }
             ''')
        self.scrollAreaWidgetContents.setStyleSheet(sc)
        self.scrollAreaWidgetContents_3.setStyleSheet(sc)
        self.scrollAreaWidgetContents_4.setStyleSheet(sc)
        b = '''
             color:white;
             background:#2B2B2B;
            '''
        self.label_0.setStyleSheet(b)
        self.label_1.setStyleSheet(b)
        self.label_2.setStyleSheet(b)
        self.label_3.setStyleSheet(b)

        MainWindow.setWindowOpacity(0.95)  # 设置窗口透明度
        MainWindow.setAttribute(Qt.WA_TranslucentBackground)
        MainWindow.setWindowFlag(Qt.FramelessWindowHint)  # 隐藏边框

    # 设置界面文字内容
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "python车牌识别系统-bhml"))
        self.label_0.setText(_translate("MainWindow", "原始识别图片："))
        self.label.setText(_translate("MainWindow", ""))
        self.label_1.setText(_translate("MainWindow", "车牌识别结果："))
        self.label_2.setText(_translate("MainWindow", "识别到的车牌："))
        self.label_3.setText(_translate("MainWindow", ""))
        self.pushButton.setText(_translate("MainWindow", "打开文件"))
        self.pushButton_2.setText(_translate("MainWindow", "导出数据"))
        self.label_4.setText(_translate("MainWindow", "功能："))
        self.scrollAreaWidgetContents_1.show()

    # 调用api接口识别
    def recognition(self, path):
        print(path)
        print("开始识别")
        Rec = Recognition()
        # 注意：path路径不能含有中文
        result = Rec.get_license_recognition(path)
        print("得到识别结果：", result)
        return result

    # 显示识别结果到表格界面
    def show_result(self, result, FileName):
        print("获取数据显示数据中")
        # 显示表格
        self.RowLength = self.RowLength + 1
        if self.RowLength > 18:
            self.tableWidget.setColumnWidth(5, 157)
        self.tableWidget.setRowCount(self.RowLength)
        self.tableWidget.setItem(self.RowLength - 1, 0, QTableWidgetItem(FileName))
        self.tableWidget.setItem(self.RowLength - 1, 1, QTableWidgetItem(result['InputTime']))
        self.tableWidget.setItem(self.RowLength - 1, 2, QTableWidgetItem(result['Number']))
        self.tableWidget.setItem(self.RowLength - 1, 3, QTableWidgetItem(result['Type']))
        # 不同的车牌显示不同的背景颜色
        if result['Type'] == '蓝色牌照':
            self.tableWidget.item(self.RowLength - 1, 3).setBackground(QBrush(QColor(3, 128, 255)))
        elif result['Type'] == '绿色牌照':
            self.tableWidget.item(self.RowLength - 1, 3).setBackground(QBrush(QColor(98, 198, 148)))
        elif result['Type'] == '黄色牌照':
            self.tableWidget.item(self.RowLength - 1, 3).setBackground(QBrush(QColor(242, 202, 9)))
        self.tableWidget.setItem(self.RowLength - 1, 4, QTableWidgetItem(result['From']))

        self.tableWidget.item(self.RowLength - 1, 0).setBackground(QBrush(QColor(255, 255, 255)))
        self.tableWidget.item(self.RowLength - 1, 1).setBackground(QBrush(QColor(255, 255, 255)))
        self.tableWidget.item(self.RowLength - 1, 2).setBackground(QBrush(QColor(255, 255, 255)))
        self.tableWidget.item(self.RowLength - 1, 4).setBackground(QBrush(QColor(255, 255, 255)))

        print("显示完成")
        # 显示识别到的车牌位置
        size = (int(self.label_3.width()), int(self.label_3.height()))
        print(size)
        shrink = cv2.resize(result['Picture'], size)
        print(shrink)
        shrink = cv2.cvtColor(shrink, cv2.COLOR_BGR2RGB)
        self.QtImg = QtGui.QImage(shrink[:], shrink.shape[1], shrink.shape[0], shrink.shape[1] * 3,
                                  QtGui.QImage.Format_RGB888)
        self.label_3.setPixmap(QtGui.QPixmap.fromImage(self.QtImg))

    # 导出识别数据到xls格式表格
    def write_xls(self, DATA, path):
        wb = xlwt.Workbook()
        ws = wb.add_sheet('Data')
        for i, Data in enumerate(DATA):
            for j, data in enumerate(Data):
                ws.write(i, j, data)
        wb.save(path)
        QMessageBox.information(None, "成功", "数据已保存！", QMessageBox.Yes)

    # 导出识别数据到csv格式表格
    def write_csv(self, DATA, path):
        f = open(path, 'w')
        for data in DATA:
            f.write((',').join(data) + '\n')
        f.close()
        QMessageBox.information(None, "成功", "数据已保存！", QMessageBox.Yes)

    # 打开保存表格文件选择框
    def write_Files(self):
        path, filetype = QFileDialog.getSaveFileName(None, "另存为", self.ProjectPath,
                                                     "Excel 工作簿(*.xls);;CSV (逗号分隔)(*.csv)")
        if path == "":  # 未选择文件夹
            return
        if filetype == 'Excel 工作簿(*.xls)':
            self.write_xls(self.Data, path)
        elif filetype == 'CSV (逗号分隔)(*.csv)':
            self.write_csv(self.Data, path)

    # 打开选择图片的文件选择框
    def open_image(self):
        path, filetype = QFileDialog.getOpenFileName(None, "选择文件", self.ProjectPath,
                                                     "JPEG Image (*.jpg);;PNG Image (*.png);;JFIF Image (*.jfif)")  # ;;All Files (*)
        if path == "":  # 未选择文件
            return
        filename = path.split('/')[-1]
        # 尺寸适配，便于放入界面显示（根据长宽比例调整）
        size = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR).shape
        if size[0] / size[1] > 1.0907:
            w = int(size[1] * self.label.height() / size[0])
            h = self.label.height()
            jpg = QtGui.QPixmap(path).scaled(w, h)
        elif size[0] / size[1] < 1.0907:
            w = self.label.width()
            h = int((size[0] * self.label.width()) / size[1])
            jpg = QtGui.QPixmap(path).scaled(w, h)
        else:
            jpg = QtGui.QPixmap(path).scaled(self.label.width(), self.label.height())
        # 显示图片
        self.label.setPixmap(jpg)
        # 识别图片，得到车牌信息
        result = self.recognition(path)

        # 封装全局变量Data
        if result is not None:
            print("开始封装Data")
            self.Data.append(
                [filename, result['InputTime'], result['Number'], result['Type'],
                 result['From']])
            self.show_result(result, filename)
            print("show ok")
        else:
            QMessageBox.warning(None, "Error", "无法识别此图像中的车牌！", QMessageBox.Yes)

    # 退出程序提示
    def close(self):
        reply = QtWidgets.QMessageBox.question(self, '提示',
                                               "是否要退出程序？\n退出后将丢失识别数据哦！",
                                               QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                                               QtWidgets.QMessageBox.No)
        if reply == QtWidgets.QMessageBox.Yes:
            sys.exit()
        else:
            pass


# 重写MainWindow类（自定义窗口事件）
class MainWindow(QtWidgets.QMainWindow):
    # 退出程序实体
    def closeEvent(self, event):
        reply = QtWidgets.QMessageBox.question(self, '提示',
                                               "是否要退出程序？\n退出后将丢失识别数据哦！",
                                               QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                                               QtWidgets.QMessageBox.No)
        if reply == QtWidgets.QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()

    # 鼠标按下事件
    def mousePressEvent(self, event):
        self.m_Position = event.globalPos() - self.pos()  # 获取鼠标相对窗口的位置
        event.accept()

    # 鼠标移动事件
    def mouseMoveEvent(self, QMouseEvent):
        self.move(QMouseEvent.globalPos() - self.m_Position)  # 更改窗口位置
        QMouseEvent.accept()

    # 最小化窗口到任务栏
    def mini(self):
        self.showMinimized()


# 程序入口（校验所需文件）
if __name__ == "__main__":
    if os.path.exists('file/provinces.json'):
        if os.path.exists('file/cardtype.json'):
            if os.path.exists('file/prefecture.json'):
                    app = QtWidgets.QApplication(sys.argv)
                    MainWindow = MainWindow()
                    ui = Ui_MainWindow()
                    ui.setupUi(MainWindow)
                    MainWindow.show()
                    sys.exit(app.exec_())
            else:
                print('未找到 prefecture.json 文件')
                RuntimeError('未找到 prefecture.json 文件')
        else:
            print('未找到 cardtype.json 文件')
            RuntimeError('未找到 cardtype.json 文件')
    else:
        print('未找到 provinces.json 文件')
        RuntimeError('未找到 provinces.json 文件')



#!/usr/bin/env python
#coding=utf-8
 
import cv2
import numpy as np
import sys,os
import time
 
import caffe
 
caffe_root = '/home/jyang/caffe/'
net_file = caffe_root + 'LPR/Proto/lpr_deploy.prototxt'
caffe_model = caffe_root + 'LPR/lpr_iter_40000.caffemodel'
mean_file = caffe_root + 'LPR/Mean/mean.npy'
 
img_path = caffe_root + 'LPR/001.png'    #图片路径
 
labels = {0 :"京", 1 :"沪", 2 :"津", 3 :"渝",4 : "冀" , 5: "晋",6: "蒙", 7: "辽",8: "吉",9: "黑",10: "苏",11: "浙",12: "皖",13: 
         "闽",14: "赣",15: "鲁",16: "豫",17: "鄂",18: "湘",19: "粤",20: "桂",   21: "琼",22: "川",23: "贵",24: "云",
       25:  "藏",26: "陕",27: "甘",28: "青",29: "宁",30: "新",31: "0",32: "1",33: "2",34: "3",35: "4",36: "5",
       37:  "6",38: "7",39: "8",40: "9",41: "A",42: "B",43: "C",44: "D",45: "E",46: "F",47: "G",48: "H",
        49: "J",50: "K",51: "L",52: "M",53: "N",54: "P",55: "Q",56: "R",57: "S",58: "T",59: "U",60: "V",
        61: "W",62: "X",63: "Y",64: "Z" };
 
if __name__=='__main__':
    net=caffe.Net(net_file,caffe_model,caffe.TEST)
    transformer=caffe.io.Transformer({'data':net.blobs['data'].data.shape})
    transformer.set_transpose('data' ,(2, 0, 1) )
    
    transformer.set_mean('data', np.load(mean_file).mean(1).mean(1) )
    transformer.set_raw_scale('data' , 255)
    #把数据从[0-1] rescale 至 [0-255]
    transformer.set_channel_swap('data' ,(2 ,1 , 0))
    #在caffe中读入是BGR(0,1,2)，所以要将RGB转化为BGR(2,1,0)
    
    start = time.time()
    img=caffe.io.load_image(img_path )
    img=img[...,::-1] 
 
    net.blobs['data'].data[...]=transformer.preprocess('data' , img)
    out=net.forward()
    
    prob=('prob_1','prob_2','prob_3','prob_4','prob_5','prob_6','prob_7')
    for k in range(7):
       index = net.blobs[prob[k]].data[0].flatten().argsort()[-1:-6:-1] 
       print labels[index[0]],
    print("\nDone in %.2f s." % (time.time()-start ))
 
    cv2.imshow( 'demo',img)
    cv2.waitKey(0)


#include<iostream>
#include "opencv2/opencv.hpp"
#include "face.h"

using namespace std;
using namespace cv;
using namespace aip;

int main()
{  
    VideoCapture cap(0); // open the default camera
    if(!cap.isOpened())  // check if we succeeded
        {
	cout<<"error!"<<endl;	    
	return -1;
	}
	cout<<"camera open success!"<<endl;

     Mat img;
     Mat grayimag;
     Mat img2;
     Mat face;

     vector<uchar> JPGbuf;
    CascadeClassifier classifier("/usr/share/opencv/haarcascades/haarcascade_frontalface_alt2.xml");
    vector<Rect> allFace;
    
    std::string app_id = "41061946";
    std::string api_key = "saAuOBAef1VI3b4tHEmeg3Ni";
    std::string secret_key = "oKNwRfOenGqfQiPPlWZmag3QwWZC6CKB";

    aip::Face client(app_id, api_key, secret_key);
    std::string base64Imag;
    Json::Value result;
    time_t sec;

    for(;;)
    {
        
        cap >> img; // get a new frame from camera
        cvtColor(img,grayimag,CV_BGR2GRAY);
        equalizeHist(grayimag, img2);
        classifier.detectMultiScale(img2,allFace);
	if(allFace.size())
{        
	rectangle(img2,allFace[0],Scalar(255,255,0));
	face=img2(allFace[0]);
	imencode(".jpg",face,JPGbuf);

        base64Imag=base64_encode((char*)JPGbuf.data(),JPGbuf.size());

        result=client.search(base64Imag, "BASE64", "Students",aip::null);
     if(!result["result"].isNull())
	{
	 if(result["result"]["user_list"][0]["score"].asInt()>80)
	   {
   	     cout<<result["result"]["user_list"][0]["user_id"]<<endl;
	     sec=time(NULL);
	     cout<<ctime(&sec)<<endl;
	putText(img2, result["result"]["user_list"][0]["user_id"].asString(), Point(0,50), FONT_HERSHEY_SIMPLEX,1.0, Scalar(255,255,255) );
	   }
	
	}
}
        imshow("video",img2);
        waitKey(30);
    }
   

    return 0;	
}
