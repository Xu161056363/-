#include<iostream>
#include "opencv2/opencv.hpp"
#include "face.h"

using namespace std;
using namespace cv;
using namespace aip;

int main()
{  
    VideoCapture cap(0); // open the default camera
    if(!cap.isOpened())  // check if we succeeded
        {
	cout<<"error!"<<endl;	    
	return -1;
	}
	cout<<"camera open success!"<<endl;

     Mat img;
     Mat grayimag;
     Mat img2;
     Mat face;

     vector<uchar> JPGbuf;
    CascadeClassifier classifier("/usr/share/opencv/haarcascades/haarcascade_frontalface_alt2.xml");
    vector<Rect> allFace;
    
    std::string app_id = "41061946";
    std::string api_key = "saAuOBAef1VI3b4tHEmeg3Ni";
    std::string secret_key = "oKNwRfOenGqfQiPPlWZmag3QwWZC6CKB";

    aip::Face client(app_id, api_key, secret_key);
    std::string base64Imag;
    Json::Value result;
    time_t sec;

    for(;;)
    {
        
        cap >> img; // get a new frame from camera
        cvtColor(img,grayimag,CV_BGR2GRAY);
        equalizeHist(grayimag, img2);
        classifier.detectMultiScale(img2,allFace);
	if(allFace.size())
{        
	rectangle(img2,allFace[0],Scalar(255,255,0));
	face=img2(allFace[0]);
	imencode(".jpg",face,JPGbuf);

        base64Imag=base64_encode((char*)JPGbuf.data(),JPGbuf.size());

        result=client.search(base64Imag, "BASE64", "Students",aip::null);
     if(!result["result"].isNull())
	{
	 if(result["result"]["user_list"][0]["score"].asInt()>80)
	   {
   	     cout<<result["result"]["user_list"][0]["user_id"]<<endl;
	     sec=time(NULL);
	     cout<<ctime(&sec)<<endl;
	putText(img2, result["result"]["user_list"][0]["user_id"].asString(), Point(0,50), FONT_HERSHEY_SIMPLEX,1.0, Scalar(255,255,255) );
	   }
	
	}
}
        imshow("video",img2);
        waitKey(30);
    }
   

    return 0;	
}
