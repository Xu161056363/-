
import base64
import json
import time
import cv2
import numpy as np
import requests


class Recognition:

    # 01初始化参数
    def __init__(self):
        self.MAX_WIDTH = 1000  # 原始图片最大宽度
        self.Min_Area = 2000  # 车牌区域允许最大面积
        self.PROVINCE_START = 1000

        # 省份代码保存在provinces.json中
        with open('file/provinces.json', 'r', encoding='utf-8') as f:
            self.provinces = json.load(f)

        # 车牌类型保存在cardtype.json中
        with open('file/cardtype.json', 'r', encoding='utf-8') as f:
            self.cardtype = json.load(f)

        # 字母所代表的地区保存在Prefecture.json中，便于更新
        with open('file/prefecture.json', 'r', encoding='utf-8') as f:
            self.prefecture = json.load(f)

        # 获取api keys
        with open('file/keys.json', 'r', encoding='utf-8') as f:
            self.keys = json.load(f)

    # 02获取token
    def get_token(self):
        host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=' + self.keys[
            'api_key'] + '&client_secret=' + self.keys['secret_key']
        response = requests.get(host)
        if response:
            token_info = response.json()
            token_key = token_info['access_token']
            return token_key
        else:
            print("token获取失败，请检查api接口")

    # 03识别车牌
    def get_license_recognition(self, car_pic):
        result = {}  # 存放识别信息结果的字典
        request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/license_plate"
        # 二进制方式打开图片文件
        f = open(car_pic, 'rb')
        img = base64.b64encode(f.read())
        params = {"image": img}
        access_token = self.get_token()
        request_url = request_url + "?access_token=" + access_token
        headers = {'content-type': 'application/x-www-form-urlencoded'}
        response = requests.post(request_url, data=params, headers=headers)
        if len(response.json()) == 3:  # 如果识别不到车牌会返回一个三个长度的key value
            return None
        if response:
            # 得到车牌号
            license_result = response.json()['words_result']['number']
            # 得到车牌位置
            license_location_no = response.json()['words_result']['vertexes_location']
            license_location = []
            for i in license_location_no:
                license_location.append((i['x'], i['y']))
            # 根据坐标分割车牌图片
            image = cv2.imread(car_pic)
            image = np.asarray(image)
            image = image[license_location[0][1]:license_location[3][1], license_location[0][0]:license_location[1][0]]
            # 显示车牌图片
            # cv2.imshow("Hello", image)
            # cv2.waitKey(0)
            # cv2.destroyAllWindows()

            # 封装车牌信息到result
            card_color = response.json()['words_result']['color']
            if license_result:
                result['InputTime'] = time.strftime("%Y-%m-%d %H:%M:%S")
                result['Type'] = self.cardtype[card_color]
                result['Picture'] = image
                result['Number'] = ''.join(license_result[:2]) + '·' + ''.join(license_result[2:])
                result['license_location'] = license_location
                try:
                    result['From'] = ''.join(self.prefecture[license_result[0]][license_result[1]])
                except:
                    result['From'] = '未知'
                return result
        else:
            return None


# 测试
if __name__ == '__main__':
    c = Recognition()
    result = c.get_license_recognition("D:/code/pythonProject/image/test.jpg")
    print(result)
