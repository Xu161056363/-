/*
 * Copyright (c) 2022 HiSilicon (Shanghai) Technologies CO., LIMITED.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <unistd.h>

#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "iot_gpio_ex.h"
#include "iot_watchdog.h"
#include "iot_pwm.h"

#define LED_INTERVAL_TIME_US 300000
#define LED_TASK_STACK_SIZE 512
#define LED_TASK_PRIO 25

static int g_beepState = 1;
static int g_iState = 0;
#define IOT_PWM_PORT_PWM0   0
#define IOT_PWM_BEEP        9
#define IOT_GPIO_KEY        8

static void *PWMBeepTask(const char *arg)
{
    while (1) {
        if (g_beepState) {
            IoTPwmStart(IOT_PWM_PORT_PWM0, 50, 4000); /* 占空比50 / 4000,频率4000 */
        } else {
            IoTPwmStop(IOT_PWM_PORT_PWM0);
        }
        if (g_iState == 0xffff) {
            g_iState = 0;
            break;
        }
    }
}

static void OnButtonPressed(const char *arg)
{
    (void) arg;
    g_beepState = !g_beepState;
    printf("PRESS_KEY!\n");
    g_iState++;
}

static void StartPWMBeepTask(void)
{
    osThreadAttr_t attr;

    IoTGpioInit(IOT_GPIO_KEY);
    IoSetFunc(IOT_GPIO_KEY, 0);
    IoTGpioSetDir(IOT_GPIO_KEY, IOT_GPIO_DIR_IN);
    IoSetPull(IOT_GPIO_KEY, IOT_IO_PULL_UP);
    IoTGpioRegisterIsrFunc(IOT_GPIO_KEY, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW, OnButtonPressed, NULL);
    IoTGpioInit(IOT_PWM_BEEP);
    IoSetFunc(IOT_PWM_BEEP, 5); /* 设置IO5的功能 */
    IoTGpioSetDir(IOT_PWM_BEEP, IOT_GPIO_DIR_OUT);
    IoTPwmInit(IOT_PWM_PORT_PWM0);
    IoTWatchDogDisable();

    attr.name = "PWMBeepTask";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 1024; /* 堆栈大小为1024 */
    attr.priority = osPriorityNormal;

    if (osThreadNew((osThreadFunc_t)PWMBeepTask, NULL, &attr) == NULL) {
        printf("[StartPWMBeepTask] Failed to create PWMBeepTask!\n");
    }
}

APP_FEATURE_INIT(StartPWMBeepTask);


#include <stdio.h>
#include <stdlib.h>
#include "pwm.h"

#define SERVO_PIN        5   // 假设舵机连接在GPIO5上
#define SERVO_FREQ       50  // 舵机PWM频率为50Hz
#define SERVO_MIN_PULSE  500 // 舵机最小脉冲宽度为500us
#define SERVO_MAX_PULSE  2500// 舵机最大脉冲宽度为2500us
#define SERVO_NEUTRAL    1500// 舵机中位脉冲宽度为1500us

void ServoWrite(int angle) {
    int pulse_width;

    // 将角度映射到脉冲宽度
    pulse_width = SERVO_MIN_PULSE + (angle * (SERVO_MAX_PULSE - SERVO_MIN_PULSE) / 180);

    // 设置PWM输出
    PwmSetPulseWidth(SERVO_PIN, pulse_width);
}

int main() {
    // 初始化PWM
    PwmInit(SERVO_PIN, SERVO_FREQ);

    // 将舵机设置到中位
    ServoWrite(90);

    // 控制舵机转动
    ServoWrite(0);   // 舵机转到0度
    ServoWrite(90); // 舵机转到90度


    // 释放资源
    PwmDeInit(SERVO_PIN);

    return 0;
}